# Changelog

## 1.1.0 — Enhanced educational prototype
- Refined UI and responsive symptom selection.
- Expanded symptom catalogue and illustrative pattern profiles.
- Improved validation, CSRF protection, configuration, and analytics.
- Added tests, .gitignore, .env.example, and updated documentation.
- Clarified educational-only status and clinical limitations.

## 2.0.0 — Phase 2 health-topic library
- Added a bilingual catalogue of 50 health topics.
- Added searchable/filterable Health Library and detail pages.
- Added four source-linked symptom summaries; other records remain pending review.
- Kept the knowledge library separate from the illustrative matching rules.

## Phase 3 — Source-tracked knowledge review
- Expanded source-checked bilingual topic summaries to 11 using official health sources.
- Added source-check metadata and review-state filters.
- Added catalogue integrity validation; knowledge entries remain disabled for matching.
- Added tests for source status and matching safeguards.

## Phase 4 — Canonical symptom and source evidence integration
- Added bilingual canonical symptom catalogue and source-tracked condition–symptom evidence map.
- Added searchable Symptom Evidence Map page.
- Kept all source-derived associations disabled for prediction pending qualified review.
- Improved common Bengali/English negation handling and added safety tests.


## Phase 5 — Explainable Matching and Safety
- Added separate storage for explicitly negated symptoms.
- Added migration for existing SQLite databases.
- Matching output now distinguishes matched, explicitly not-present, and not-assessed symptoms.
- Improved explanation and score interpretation on result reports.
- Added tests for matching explanations and negation separation.


## Phase 6 — verification and security hardening
- Added conservative browser security response headers.
- Marked screening report responses as non-cacheable (`no-store`).
- Added regression tests for security headers and report cache behavior.
- Performed static Python compilation, JSON parsing, catalogue integrity checks, and ZIP validation.
- Full Flask runtime tests remain to be run on a machine with project dependencies installed.


## Phase 7 — UI polish and accessibility
- Added keyboard skip link, visible focus treatment, accessible mobile navigation, and Escape-to-close behavior.
- Added bilingual symptom search empty state and live selected-symptom count.
- Clarified the assessment form's review-before-analysis action.
- Added print-report control and print stylesheet.
- Added UI regression tests.

## Phase 7 update — expanded symptom catalogue
- Expanded the bilingual symptom catalogue from 53 to 100 unique patient-reported terms.
- Added the 47 new catalogue terms to the patient symptom selector and conservative English/Bengali phrase suggestion lookup.
- Kept the existing illustrative pattern-matching logic and clinical safety wording unchanged. The displayed similarity score is not a disease probability or diagnostic confidence; the new terms are not automatically treated as clinically validated disease associations.
