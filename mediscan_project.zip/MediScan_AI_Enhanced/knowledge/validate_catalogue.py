"""Validate MediScan educational topic catalogue integrity (not clinical validity)."""
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
DATA = json.loads((BASE / "conditions.json").read_text(encoding="utf-8"))
rows = DATA.get("conditions", [])
errors = []
ids = [r.get("id") for r in rows]
if len(ids) != len(set(ids)):
    errors.append("Duplicate topic IDs")
if DATA.get("count") != len(rows):
    errors.append("Top-level count does not match records")
for r in rows:
    for key in ("id", "name_en", "name_bn", "category", "summary_en", "summary_bn", "source_name", "source_url", "review_status"):
        if not r.get(key):
            errors.append(f"{r.get('id', '<unknown>')}: missing {key}")
    if r.get("usable_for_matching") is not False:
        errors.append(f"{r.get('id')}: library item must remain disabled for matching")
    if not r.get("source_url", "").startswith("https://"):
        errors.append(f"{r.get('id')}: source URL must use HTTPS")
if errors:
    print("CATALOGUE VALIDATION FAILED")
    print("\n".join(errors))
    raise SystemExit(1)
source_checked = sum(r.get("content_review") == "source_content_checked_and_bilingual_summary_added" for r in rows)
pending = sum(r.get("review_status") == "pending_condition_specific_review" for r in rows)
print(f"Catalogue integrity OK: {len(rows)} topics; {source_checked} source summaries checked; {pending} pending condition-specific review.")
print("Clinical validation: NOT performed. No topic is enabled for matching.")
