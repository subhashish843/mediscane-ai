# MediScan AI — Source Review and Enhancement Notes

## What this project is
A Flask + SQLite educational symptom-pattern screening prototype. It uses manually authored weighted rules, not a trained machine-learning model or external AI API.

## Changes in this enhanced version
- Expanded from 7 to 17 illustrative symptom-pattern profiles.
- Expanded from 23 to 53 selectable symptoms, organized into categories.
- Added live symptom search.
- Improved result explanation with matched symptom details.
- Made the score label and disclaimer clearer: scores are rule-profile similarity indices, not probabilities or diagnoses.
- Added additional emergency warning prompts.
- Added CSRF token checks to POST forms.
- Added symptom allow-list validation, duplicate removal, age validation, and sex-value allow-listing.
- Moved Flask secret configuration to an environment variable with a random local fallback.
- Disabled debug mode by default and bound the development server to localhost.
- Added SQLite indexes and more robust stored-symptom parsing.
- Corrected analytics to chart counts by top matching pattern rather than treating recent match scores as activity counts.
- Added automated tests and setup documentation.

## Important limitations retained honestly
- The weights and profiles are hand-authored and not clinically validated.
- Age and sex are recorded but do not affect matching.
- The app is not a diagnostic tool and does not estimate disease probability or clinical risk.
- No trained ML model, authentication, production deployment stack, or clinical validation is included.
- The symptom/profile list is illustrative and incomplete.

## Verification performed in this environment
- Python source compilation succeeded.
- Static inspection found 53 unique symptom keys and 17 profiles.
- All profile symptom keys map to a known symptom.
- Runtime Flask tests could not be executed in this environment because Flask is not installed and package installation was unavailable. Run the documented test command after installing requirements locally.
