"""MediScan AI: educational symptom-pattern screening prototype.

This application uses hand-authored weighted rules, NOT a trained ML model.
Similarity scores are not disease probabilities, diagnoses, or clinical risk.
Use fictional data only; this is not validated for clinical decisions.
"""
from __future__ import annotations

import hmac
import json
import logging
import os
import re
import secrets
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from flask import Flask, abort, flash, redirect, render_template, request, session, url_for

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = Path(os.environ.get("MEDISCAN_DB_PATH", str(BASE_DIR / "mediscan.db"))).expanduser()

app = Flask(__name__)
app.config.update(
    SECRET_KEY=os.environ.get("MEDISCAN_SECRET_KEY") or secrets.token_hex(32),
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("MEDISCAN_COOKIE_SECURE", "0") == "1",
    MAX_CONTENT_LENGTH=32 * 1024,
)
logging.basicConfig(level=os.environ.get("LOG_LEVEL", "INFO"))
logger = logging.getLogger("mediscan")

KNOWLEDGE_PATH = BASE_DIR / "knowledge" / "conditions.json"
def validate_condition_library(rows: list[dict[str, Any]]) -> list[str]:
    """Return catalogue integrity issues; never promotes records into matching rules."""
    issues: list[str] = []
    seen: set[str] = set()
    for index, row in enumerate(rows):
        if not isinstance(row, dict):
            issues.append(f"Record {index} is not an object")
            continue
        cid = row.get("id")
        if not isinstance(cid, str) or not cid.strip():
            issues.append(f"Record {index} has no id")
        elif cid in seen:
            issues.append(f"Duplicate condition id: {cid}")
        else:
            seen.add(cid)
        for field in ("name_en", "name_bn", "category", "source_name", "source_url", "review_status"):
            if not isinstance(row.get(field), str) or not row[field].strip():
                issues.append(f"{cid or index}: missing {field}")
        url = row.get("source_url", "")
        if url and not (url.startswith("https://www.nhs.uk/") or url.startswith("https://nhs.uk/") or url.startswith("https://medlineplus.gov/") or url.startswith("https://www.medlineplus.gov/") or url.startswith("https://www.cdc.gov/") or url.startswith("https://www.who.int/")):
            issues.append(f"{cid or index}: source URL is outside the approved source host allow-list")
        symptom_ids = row.get("symptom_ids", [])
        if not isinstance(symptom_ids, list):
            issues.append(f"{cid or index}: symptom_ids must be a list")
        # Catalogue summaries are never matching rules. Even source-checked content
        # requires a separate qualified clinical review and validated rule specification.
        if row.get("usable_for_matching") is True:
            issues.append(f"{cid or index}: knowledge-library record must not be enabled for matching")
    return issues


def load_condition_library() -> list[dict[str, Any]]:
    """Load educational topics; catalogue records are never used for prediction."""
    try:
        payload = json.loads(KNOWLEDGE_PATH.read_text(encoding="utf-8"))
        rows = payload.get("conditions", [])
        if not isinstance(rows, list):
            raise ValueError("conditions must be a list")
        issues = validate_condition_library(rows)
        if issues:
            logger.error("Knowledge catalogue validation issues: %s", "; ".join(issues[:20]))
        return rows
    except (OSError, json.JSONDecodeError, AttributeError, ValueError):
        logger.exception("Could not load condition knowledge catalogue")
        return []

CONDITION_LIBRARY = load_condition_library()
KNOWLEDGE_ISSUES = validate_condition_library(CONDITION_LIBRARY)

SYMPTOM_CATALOG_PATH = BASE_DIR / "knowledge" / "symptoms.json"
CONDITION_SYMPTOM_EVIDENCE_PATH = BASE_DIR / "knowledge" / "condition_symptom_evidence.json"

def load_json_object(path: Path, default: dict[str, Any]) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else default
    except (OSError, json.JSONDecodeError):
        logger.exception("Could not load knowledge file: %s", path.name)
        return default

SYMPTOM_CATALOG = load_json_object(SYMPTOM_CATALOG_PATH, {"symptoms": []})
CONDITION_SYMPTOM_EVIDENCE = load_json_object(CONDITION_SYMPTOM_EVIDENCE_PATH, {"associations": []})

def validate_phase4_knowledge() -> list[str]:
    issues: list[str] = []
    known = {row.get("id") for row in SYMPTOM_CATALOG.get("symptoms", []) if isinstance(row, dict)}
    for row in CONDITION_SYMPTOM_EVIDENCE.get("associations", []):
        if row.get("condition_id") not in {c.get("id") for c in CONDITION_LIBRARY}:
            issues.append(f"Unknown condition id: {row.get('condition_id')}")
        for symptom_id in row.get("symptom_ids", []):
            if symptom_id not in known:
                issues.append(f"Unknown symptom id {symptom_id} in {row.get('condition_id')}")
        if row.get("usable_for_matching") is not False or row.get("clinician_reviewed") is not False:
            issues.append(f"Unsafe matching/review flag in {row.get('condition_id')}")
    return issues

PHASE4_KNOWLEDGE_ISSUES = validate_phase4_knowledge()

# Symptom key, display label, category. Categories are for navigation only.
SYMPTOMS = [
    ("fever", "Fever", "General"), ("mild_fever", "Mild fever", "General"),
    ("chills", "Chills", "General"), ("fatigue", "Fatigue / tiredness", "General"),
    ("body_ache", "Body aches", "General"), ("headache", "Headache", "Neurological"),
    ("dizziness", "Dizziness", "Neurological"), ("fainting", "Fainting / loss of consciousness", "Warning signs"),
    ("confusion", "New confusion / difficult to wake", "Warning signs"),
    ("weakness_one_side", "Sudden weakness on one side", "Warning signs"),
    ("sudden_severe_headache", "Sudden extremely severe headache", "Warning signs"),
    ("rash", "Rash", "Skin"), ("itching_skin", "Itchy skin", "Skin"),
    ("hives_swelling", "Sudden hives or face/tongue swelling", "Warning signs"),
    ("cough", "Cough", "Respiratory"), ("dry_cough", "Dry cough", "Respiratory"),
    ("sore_throat", "Sore throat", "Respiratory"), ("runny_nose", "Runny nose", "Respiratory"),
    ("sneezing", "Sneezing", "Respiratory"), ("nasal_congestion", "Nasal congestion", "Respiratory"),
    ("loss_taste_smell", "Loss of taste or smell", "Respiratory"),
    ("shortness_breath", "Severe or new shortness of breath", "Warning signs"),
    ("wheezing", "Wheezing", "Respiratory"), ("chest_tightness", "Chest tightness", "Respiratory"),
    ("chest_pain", "Chest pain or pressure", "Warning signs"),
    ("blue_lips", "Bluish / grey lips or face", "Warning signs"),
    ("palpitations", "Fast or irregular heartbeat", "Cardiovascular"),
    ("leg_swelling", "New leg swelling", "Cardiovascular"),
    ("nausea", "Nausea", "Digestive"), ("vomiting", "Vomiting", "Digestive"),
    ("diarrhea", "Diarrhea", "Digestive"), ("constipation", "Constipation", "Digestive"),
    ("stomach_pain", "Stomach / abdominal pain", "Digestive"),
    ("heartburn", "Heartburn / burning in chest after meals", "Digestive"),
    ("acid_regurgitation", "Acid / sour taste coming up", "Digestive"),
    ("bloating", "Bloating / gas", "Digestive"), ("blood_stool", "Blood in stool", "Warning signs"),
    ("pain_behind_eyes", "Pain behind the eyes", "Neurological"),
    ("light_sensitivity", "Light sensitivity", "Neurological"),
    ("sound_sensitivity", "Sound sensitivity", "Neurological"),
    ("facial_pressure", "Facial pressure / sinus discomfort", "ENT / Eyes"),
    ("ear_pain", "Ear pain", "ENT / Eyes"), ("itchy_eyes", "Itchy eyes", "ENT / Eyes"),
    ("red_watery_eyes", "Red or watery eyes", "ENT / Eyes"),
    ("pain_urination", "Pain or burning during urination", "Urinary"),
    ("frequent_urination", "Frequent urination", "Urinary"),
    ("urgent_urination", "Sudden urge to urinate", "Urinary"),
    ("blood_urine", "Blood in urine", "Warning signs"),
    ("flank_pain", "Side / flank / back pain", "Urinary"),
    ("joint_pain", "Joint pain", "Musculoskeletal"),
    ("muscle_stiffness", "Muscle stiffness", "Musculoskeletal"),
    ("back_pain", "Back pain", "Musculoskeletal"),
    ("dehydration_signs", "Very little urine / marked dehydration", "Warning signs"),
]
SYMPTOM_LABELS = {key: label for key, label, _ in SYMPTOMS}


SYMPTOM_BN = {'fever': 'জ্বর', 'mild_fever': 'হালকা জ্বর', 'chills': 'কাঁপুনি', 'fatigue': 'ক্লান্তি / অবসাদ', 'body_ache': 'শরীর ব্যথা', 'headache': 'মাথাব্যথা', 'dizziness': 'মাথা ঘোরা', 'fainting': 'অজ্ঞান হওয়া', 'confusion': 'বিভ্রান্তি / জাগাতে অসুবিধা', 'weakness_one_side': 'শরীরের এক পাশে হঠাৎ দুর্বলতা', 'sudden_severe_headache': 'হঠাৎ অত্যন্ত তীব্র মাথাব্যথা', 'rash': 'ত্বকে ফুসকুড়ি', 'itching_skin': 'ত্বকে চুলকানি', 'hives_swelling': 'হঠাৎ চাকা ওঠা বা মুখ / জিহ্বা ফুলে যাওয়া', 'cough': 'কাশি', 'dry_cough': 'শুকনো কাশি', 'sore_throat': 'গলাব্যথা', 'runny_nose': 'নাক দিয়ে পানি পড়া', 'sneezing': 'হাঁচি', 'nasal_congestion': 'নাক বন্ধ', 'loss_taste_smell': 'স্বাদ বা গন্ধ কমে যাওয়া', 'shortness_breath': 'শ্বাসকষ্ট', 'wheezing': 'শ্বাসে সাঁই সাঁই শব্দ', 'chest_tightness': 'বুকে চাপ / আঁটসাঁট ভাব', 'chest_pain': 'বুকে ব্যথা বা চাপ', 'blue_lips': 'ঠোঁট বা মুখ নীলচে / ধূসর হওয়া', 'palpitations': 'হৃদস্পন্দন দ্রুত বা অনিয়মিত হওয়া', 'leg_swelling': 'পা ফুলে যাওয়া', 'nausea': 'বমি বমি ভাব', 'vomiting': 'বমি', 'diarrhea': 'ডায়রিয়া / পাতলা পায়খানা', 'constipation': 'কোষ্ঠকাঠিন্য', 'stomach_pain': 'পেটব্যথা', 'heartburn': 'বুকজ্বালা', 'acid_regurgitation': 'মুখে টক / অ্যাসিড উঠে আসা', 'bloating': 'পেট ফাঁপা / গ্যাস', 'blood_stool': 'পায়খানায় রক্ত', 'pain_behind_eyes': 'চোখের পেছনে ব্যথা', 'light_sensitivity': 'আলোতে অস্বস্তি', 'sound_sensitivity': 'শব্দে অস্বস্তি', 'facial_pressure': 'মুখমণ্ডলে চাপ / সাইনাসে অস্বস্তি', 'ear_pain': 'কানে ব্যথা', 'itchy_eyes': 'চোখ চুলকানো', 'red_watery_eyes': 'চোখ লাল হওয়া বা পানি পড়া', 'pain_urination': 'প্রস্রাবে ব্যথা / জ্বালা', 'frequent_urination': 'ঘন ঘন প্রস্রাব', 'urgent_urination': 'হঠাৎ প্রস্রাবের তাগিদ', 'blood_urine': 'প্রস্রাবে রক্ত', 'flank_pain': 'কোমরের পাশ / পিঠের পাশে ব্যথা', 'joint_pain': 'জয়েন্টে ব্যথা', 'muscle_stiffness': 'পেশি শক্ত হয়ে থাকা', 'back_pain': 'পিঠে ব্যথা', 'dehydration_signs': 'প্রস্রাব খুব কম হওয়া / পানিশূন্যতার লক্ষণ'}
SYMPTOM_ALIASES = {'fever': ['fever', 'high temperature', 'জ্বর', 'গা গরম', 'তাপমাত্রা বেশি'], 'mild_fever': ['mild fever', 'low grade fever', 'হালকা জ্বর'], 'chills': ['chills', 'shivering', 'কাঁপুনি', 'ঠান্ডা লাগা'], 'fatigue': ['fatigue', 'tiredness', 'weakness', 'ক্লান্তি', 'অবসাদ', 'দুর্বল লাগছে'], 'body_ache': ['body ache', 'body pain', 'শরীর ব্যথা', 'গা ব্যথা', 'সারা শরীর ব্যথা'], 'headache': ['headache', 'head pain', 'মাথাব্যথা', 'মাথা ব্যথা'], 'dizziness': ['dizziness', 'dizzy', 'মাথা ঘোরা', 'ঝিমঝিম'], 'fainting': ['fainting', 'passed out', 'অজ্ঞান', 'জ্ঞান হারানো'], 'confusion': ['confusion', 'disoriented', 'বিভ্রান্তি', 'এলোমেলো কথা'], 'weakness_one_side': ['one sided weakness', 'weakness on one side', 'এক পাশে দুর্বলতা', 'শরীরের এক পাশ অবশ'], 'sudden_severe_headache': ['sudden severe headache', 'worst headache', 'হঠাৎ প্রচণ্ড মাথাব্যথা'], 'rash': ['rash', 'skin rash', 'ফুসকুড়ি', 'চামড়ায় দানা'], 'itching_skin': ['itching', 'itchy skin', 'চুলকানি', 'গা চুলকায়'], 'hives_swelling': ['hives', 'face swelling', 'tongue swelling', 'মুখ ফুলে যাওয়া', 'জিহ্বা ফুলে যাওয়া'], 'cough': ['cough', 'কাশি'], 'dry_cough': ['dry cough', 'শুকনো কাশি'], 'sore_throat': ['sore throat', 'গলাব্যথা', 'গলা ব্যথা'], 'runny_nose': ['runny nose', 'নাক দিয়ে পানি', 'নাক দিয়ে জল পড়া'], 'sneezing': ['sneezing', 'হাঁচি'], 'nasal_congestion': ['blocked nose', 'stuffy nose', 'নাক বন্ধ'], 'loss_taste_smell': ['loss of taste', 'loss of smell', 'স্বাদ পাচ্ছি না', 'গন্ধ পাচ্ছি না', 'স্বাদ কমে গেছে', 'গন্ধ কমে গেছে'], 'shortness_breath': ['shortness of breath', 'breathlessness', 'difficulty breathing', 'শ্বাসকষ্ট', 'শ্বাস নিতে কষ্ট'], 'wheezing': ['wheezing', 'শ্বাসে সাঁই সাঁই', 'বুকে শোঁ শোঁ'], 'chest_tightness': ['chest tightness', 'বুকে চাপ', 'বুক আঁটসাঁট'], 'chest_pain': ['chest pain', 'chest pressure', 'বুকে ব্যথা', 'বুকে চাপ লাগছে'], 'blue_lips': ['blue lips', 'bluish lips', 'ঠোঁট নীল', 'ঠোঁট নীলচে'], 'palpitations': ['palpitations', 'racing heartbeat', 'হৃদস্পন্দন বেড়ে যাওয়া', 'বুক ধড়ফড়'], 'leg_swelling': ['leg swelling', 'পা ফুলে যাওয়া'], 'nausea': ['nausea', 'feeling sick', 'বমি বমি ভাব', 'বমি আসছে'], 'vomiting': ['vomiting', 'throwing up', 'বমি', 'বমি হচ্ছে'], 'diarrhea': ['diarrhea', 'loose motion', 'পাতলা পায়খানা', 'ডায়রিয়া'], 'constipation': ['constipation', 'কোষ্ঠকাঠিন্য', 'পায়খানা হচ্ছে না'], 'stomach_pain': ['stomach pain', 'abdominal pain', 'পেটব্যথা', 'পেটে ব্যথা'], 'heartburn': ['heartburn', 'বুকজ্বালা', 'বুকে জ্বালা'], 'acid_regurgitation': ['acid reflux', 'acid coming up', 'মুখে টক জল', 'টক ঢেকুর'], 'bloating': ['bloating', 'gas', 'পেট ফাঁপা', 'গ্যাস'], 'blood_stool': ['blood in stool', 'রক্ত পায়খানা', 'পায়খানায় রক্ত'], 'pain_behind_eyes': ['pain behind eyes', 'চোখের পেছনে ব্যথা'], 'light_sensitivity': ['light sensitivity', 'photophobia', 'আলো সহ্য হয় না', 'আলোতে কষ্ট'], 'sound_sensitivity': ['sound sensitivity', 'শব্দে কষ্ট'], 'facial_pressure': ['facial pressure', 'sinus pressure', 'মুখে চাপ', 'সাইনাসে চাপ'], 'ear_pain': ['ear pain', 'কানে ব্যথা'], 'itchy_eyes': ['itchy eyes', 'চোখ চুলকায়'], 'red_watery_eyes': ['red eyes', 'watery eyes', 'চোখ লাল', 'চোখ দিয়ে পানি'], 'pain_urination': ['painful urination', 'burning urination', 'প্রস্রাবে জ্বালা', 'প্রস্রাবে ব্যথা'], 'frequent_urination': ['frequent urination', 'ঘন ঘন প্রস্রাব'], 'urgent_urination': ['urgent urination', 'প্রস্রাবের তাড়া'], 'blood_urine': ['blood in urine', 'প্রস্রাবে রক্ত'], 'flank_pain': ['flank pain', 'side pain', 'কোমরের পাশে ব্যথা', 'পিঠের পাশে ব্যথা'], 'joint_pain': ['joint pain', 'জয়েন্টে ব্যথা', 'গাঁটে ব্যথা'], 'muscle_stiffness': ['muscle stiffness', 'পেশি শক্ত', 'পেশিতে টান'], 'back_pain': ['back pain', 'পিঠে ব্যথা', 'কোমর ব্যথা'], 'dehydration_signs': ['dehydration', 'very little urine', 'প্রস্রাব কম', 'পানিশূন্যতা']}

# Illustrative pattern profiles only. Weights are not clinical evidence.
CONDITIONS: dict[str, dict[str, Any]] = {
    "Common cold-like pattern": {"weights": {"runny_nose": 4, "sneezing": 3, "sore_throat": 3, "cough": 2, "mild_fever": 1, "nasal_congestion": 2}, "explanation": "The selected symptoms overlap with a common upper-respiratory pattern.", "guidance": "Consider professional advice if symptoms are severe, persistent, or worsening."},
    "Influenza-like pattern": {"weights": {"fever": 4, "fatigue": 4, "body_ache": 4, "headache": 3, "cough": 3, "chills": 2, "sore_throat": 1}, "explanation": "Fever, fatigue, chills and body aches can occur with influenza and other infections.", "guidance": "A healthcare professional can advise whether assessment or testing is appropriate."},
    "COVID-19-like pattern": {"weights": {"fever": 3, "cough": 3, "fatigue": 3, "sore_throat": 2, "loss_taste_smell": 4, "headache": 2, "nasal_congestion": 1}, "explanation": "Some selected symptoms can occur with COVID-19, but they are not specific to it.", "guidance": "Consider appropriate testing and follow current local public-health guidance."},
    "Dengue-like symptom pattern": {"weights": {"fever": 4, "headache": 3, "body_ache": 4, "rash": 2, "nausea": 2, "pain_behind_eyes": 4, "joint_pain": 2}, "explanation": "This symptom combination can overlap with dengue and several other illnesses; symptoms alone cannot distinguish them.", "guidance": "Seek prompt medical assessment if dengue is possible. Avoid self-medicating; ask a clinician about safe medicines."},
    "Allergic rhinitis-like pattern": {"weights": {"sneezing": 4, "runny_nose": 4, "itchy_eyes": 4, "nasal_congestion": 3}, "explanation": "Sneezing, nasal symptoms and itchy eyes can occur with allergic rhinitis.", "guidance": "Discuss persistent or troublesome symptoms with a healthcare professional."},
    "Migraine-like pattern": {"weights": {"headache": 4, "nausea": 2, "light_sensitivity": 3, "sound_sensitivity": 2}, "explanation": "The selected symptoms can overlap with migraine, but headaches have many possible causes.", "guidance": "Seek medical assessment for recurring headaches or any sudden, severe, unusual headache."},
    "Gastroenteritis-like pattern": {"weights": {"nausea": 3, "vomiting": 4, "diarrhea": 4, "stomach_pain": 3, "fever": 1, "bloating": 1}, "explanation": "These symptoms can occur with gastrointestinal infections and other digestive conditions.", "guidance": "Seek care for dehydration, blood in stool, severe pain, or persistent vomiting."},
    "Sinusitis-like pattern": {"weights": {"nasal_congestion": 4, "facial_pressure": 4, "headache": 2, "runny_nose": 2, "cough": 1}, "explanation": "Nasal congestion and facial pressure can occur with sinus inflammation, including viral causes.", "guidance": "Seek professional advice if symptoms are severe, prolonged, or worsening."},
    "Asthma-like symptom pattern": {"weights": {"wheezing": 4, "chest_tightness": 4, "shortness_breath": 3, "dry_cough": 2, "cough": 1}, "explanation": "Wheezing, chest tightness and cough can occur with asthma and other respiratory conditions.", "guidance": "New or severe breathing difficulty requires urgent medical assessment; this tool cannot assess breathing severity."},
    "Bronchitis-like pattern": {"weights": {"cough": 4, "dry_cough": 2, "fatigue": 2, "chest_tightness": 1, "mild_fever": 1}, "explanation": "Cough and fatigue can overlap with bronchitis and many respiratory infections.", "guidance": "Seek advice for breathing difficulty, persistent fever, or symptoms that worsen."},
    "Urinary infection-like pattern": {"weights": {"pain_urination": 4, "frequent_urination": 3, "urgent_urination": 3, "stomach_pain": 1}, "explanation": "Urinary discomfort and frequency can occur with urinary tract problems; testing may be needed to determine the cause.", "guidance": "Seek clinical assessment, especially with fever, flank pain, pregnancy, or worsening symptoms."},
    "Kidney stone-like symptom pattern": {"weights": {"flank_pain": 4, "blood_urine": 3, "nausea": 2, "vomiting": 1, "stomach_pain": 2}, "explanation": "Flank pain and urinary changes can have several causes, including stones; this pattern is not diagnostic.", "guidance": "Seek prompt medical assessment for severe pain, blood in urine, fever, or vomiting."},
    "Acid reflux-like pattern": {"weights": {"heartburn": 4, "acid_regurgitation": 4, "bloating": 1, "nausea": 1}, "explanation": "Heartburn and acid regurgitation can overlap with reflux symptoms, but chest discomfort may have other causes.", "guidance": "New, severe, or pressure-like chest pain needs urgent assessment rather than self-classification."},
    "Constipation-like pattern": {"weights": {"constipation": 4, "stomach_pain": 2, "bloating": 3, "nausea": 1}, "explanation": "Constipation, bloating and abdominal discomfort can occur together for many reasons.", "guidance": "Seek medical advice for severe pain, vomiting, blood in stool, or persistent symptoms."},
    "Conjunctivitis-like pattern": {"weights": {"red_watery_eyes": 4, "itchy_eyes": 3}, "explanation": "Red, watery or itchy eyes can occur with conjunctivitis, allergy and other eye conditions.", "guidance": "Eye pain, vision changes, light sensitivity, injury, or contact-lens-related redness needs prompt professional assessment."},
    "Ear infection-like pattern": {"weights": {"ear_pain": 4, "fever": 2, "headache": 1}, "explanation": "Ear pain with fever can occur with ear infections and other ear conditions.", "guidance": "Seek assessment for severe pain, discharge, hearing changes, or persistent symptoms."},
    "Tension-type headache-like pattern": {"weights": {"headache": 4, "muscle_stiffness": 2}, "explanation": "Headache with muscle tension can overlap with tension-type headache, but other causes must be considered.", "guidance": "Sudden severe headache, fainting, confusion, weakness, fever with stiff neck, or vision changes need urgent assessment."},
}

URGENT_FLAGS = {
    "shortness_breath": "new or severe shortness of breath",
    "chest_pain": "chest pain or pressure",
    "confusion": "new confusion or difficulty waking",
    "blue_lips": "bluish or grey lips/face",
    "fainting": "fainting or loss of consciousness",
    "weakness_one_side": "sudden weakness on one side",
    "sudden_severe_headache": "sudden extremely severe headache",
    "hives_swelling": "sudden hives with face or tongue swelling",
    "blood_stool": "blood in stool",
    "blood_urine": "blood in urine",
    "dehydration_signs": "marked dehydration or very little urine",
}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def db() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db() -> None:
    with db() as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS screenings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL,
            age INTEGER,
            sex TEXT,
            symptoms TEXT NOT NULL,
            top_match TEXT,
            top_score INTEGER
        )""")
        conn.execute("""CREATE TABLE IF NOT EXISTS feedback (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL,
            screening_id INTEGER,
            rating TEXT NOT NULL,
            comment TEXT,
            FOREIGN KEY(screening_id) REFERENCES screenings(id) ON DELETE SET NULL
        )""")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_screenings_created ON screenings(created_at)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_feedback_created ON feedback(created_at)")
        # Phase 5: preserve explicitly negated symptoms separately from present symptoms.
        columns = {row["name"] for row in conn.execute("PRAGMA table_info(screenings)").fetchall()}
        if "negated_symptoms" not in columns:
            conn.execute("ALTER TABLE screenings ADD COLUMN negated_symptoms TEXT NOT NULL DEFAULT '[]'")



NEGATION_PREFIX_EN = re.compile(r"(?:\bno|\bnot|\bwithout|\bdon't have|\bdo not have|\bdoesn't have|\bdoes not have|\bnever)\s+(?:any\s+)?$", re.I)
NEGATION_SUFFIX_BN = re.compile(r"(?:নেই|নাই|হয় না|হয় না|হচ্ছে না|হচ্ছে-না|হয়নি|হয়নি|ছিল না|ছিলনা)")


# Include additional catalogue symptoms in the patient UI and conservative text lookup.
for _row in SYMPTOM_CATALOG.get("symptoms", []):
    _sid = _row.get("id")
    if _sid and _sid not in SYMPTOM_LABELS:
        _label = _row.get("label_en", _sid.replace("_", " ").title())
        _category = _row.get("category", "General")
        SYMPTOMS.append((_sid, _label, _category))
        SYMPTOM_LABELS[_sid] = _label
        SYMPTOM_BN[_sid] = _row.get("label_bn", _label)
        SYMPTOM_ALIASES[_sid] = list(dict.fromkeys([_label.lower(), _row.get("label_bn", ""), *_row.get("aliases", [])]))
SYMPTOM_KEYS = set(SYMPTOM_LABELS)

def extract_symptoms_from_text(text: str) -> dict[str, list[str]]:
    """Conservative bilingual phrase lookup; every suggestion requires confirmation.

    This is not NLP or medical interpretation. Unrecognized text remains a note;
    it is never converted to a negative finding and never enters matching.
    """
    normalized = " ".join((text or "").lower().replace("।", ".").split())[:1200]
    found: list[str] = []
    negated: list[str] = []
    for key, phrases in SYMPTOM_ALIASES.items():
        for phrase in sorted(phrases, key=len, reverse=True):
            p = phrase.lower()
            if not p:
                continue
            match = re.search(re.escape(p), normalized)
            if not match:
                continue
            start, end = match.span()
            context = normalized[max(0, start - 36):start]
            after = normalized[end:end + 28]
            is_negated = bool(NEGATION_PREFIX_EN.search(context)) or bool(NEGATION_SUFFIX_BN.search(after))
            if is_negated:
                negated.append(key)
            else:
                found.append(key)
            break
    return {"suggested": list(dict.fromkeys(found)), "negated": list(dict.fromkeys(negated)), "uncertain": []}


def symptom_groups() -> dict[str, list[tuple[str, str, str]]]:
    groups: dict[str, list[tuple[str, str, str]]] = {}
    for key, label, group in SYMPTOMS:
        groups.setdefault(group, []).append((key, label, SYMPTOM_BN.get(key, label)))
    return groups


def calculate_matches(selected: list[str], negated: list[str] | None = None) -> list[dict[str, Any]]:
    """Transparent illustrative rule-profile overlaps; unselected means not assessed."""
    selected_set = set(selected)
    negated_set = set(negated or [])
    matches = []
    for name, condition in CONDITIONS.items():
        weights = condition["weights"]
        denominator = sum(weights.values())
        if denominator <= 0:
            continue
        matched = [symptom for symptom, weight in weights.items()
                   if weight > 0 and symptom in selected_set]
        matched_points = sum(weights[symptom] for symptom in matched)
        if matched_points:
            not_assessed = [symptom for symptom in weights if symptom not in selected_set and symptom not in negated_set]
            explicitly_not_present = [symptom for symptom in weights if symptom in negated_set]
            score = round(100 * matched_points / denominator)
            matches.append({
                "name": name, "score": score,
                "score_label": "Illustrative rule-profile similarity",
                "explanation": condition["explanation"], "guidance": condition["guidance"],
                "matched": [SYMPTOM_LABELS[s] for s in matched],
                "not_assessed": [SYMPTOM_LABELS[s] for s in not_assessed],
                "explicitly_not_present": [SYMPTOM_LABELS[s] for s in explicitly_not_present],
                "matched_points": matched_points, "profile_total_points": denominator,
                "matched_count": len(matched), "profile_count": len(weights),
                "interpretation": "This score shows overlap with a manually authored profile only. It is not a disease probability, diagnostic confidence, or clinical risk estimate."
            })
    return sorted(matches, key=lambda item: (item["score"], item["matched_count"]), reverse=True)[:5]


def csrf_token() -> str:
    token = session.get("csrf_token")
    if not token:
        token = secrets.token_urlsafe(32)
        session["csrf_token"] = token
    return token


@app.after_request
def add_security_headers(response):
    """Add conservative browser protections without breaking local development assets."""
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "DENY")
    response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    response.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
    # Screening pages contain locally stored health-related information.
    if request.path.startswith("/prediction/"):
        response.headers["Cache-Control"] = "no-store"
    return response


@app.context_processor
def inject_globals():
    return {"current_year": datetime.now().year, "csrf_token": csrf_token, "condition_count": len(CONDITIONS), "symptom_count": len(SYMPTOMS), "symptom_bn": SYMPTOM_BN, "knowledge_count": len(CONDITION_LIBRARY), "knowledge_source_checked_count": sum(1 for x in CONDITION_LIBRARY if x.get("content_review") == "source_content_checked_and_bilingual_summary_added"), "knowledge_pending_count": sum(1 for x in CONDITION_LIBRARY if x.get("review_status") == "pending_condition_specific_review")}


@app.before_request
def protect_post_requests():
    if request.method == "POST":
        sent = request.form.get("csrf_token", "")
        expected = session.get("csrf_token", "")
        if not sent or not expected or not hmac.compare_digest(sent, expected):
            abort(400, description="Your form session expired. Refresh the page and try again.")


@app.route("/")
def dashboard():
    with db() as conn:
        total = conn.execute("SELECT COUNT(*) FROM screenings").fetchone()[0]
        recent = conn.execute("SELECT * FROM screenings ORDER BY id DESC LIMIT 8").fetchall()
        feedback_count = conn.execute("SELECT COUNT(*) FROM feedback").fetchone()[0]
        grouped = conn.execute("SELECT top_match, COUNT(*) AS count FROM screenings GROUP BY top_match ORDER BY count DESC LIMIT 8").fetchall()
    return render_template("dashboard.html", active="dashboard", total=total, recent=recent,
                           feedback_count=feedback_count, grouped=grouped)


@app.route("/patient", methods=["GET", "POST"])
def patient():
    if request.method == "POST":
        submitted = request.form.getlist("symptoms")
        selected = list(dict.fromkeys(s for s in submitted if s in SYMPTOM_KEYS))
        description = request.form.get("symptom_description", "").strip()[:1200]
        extraction = extract_symptoms_from_text(description)
        suggestions = [s for s in extraction["suggested"] if s not in selected]
        age_raw = request.form.get("age", "").strip()
        sex = request.form.get("sex", "Not specified")
        allowed_sex = {"Not specified", "Female", "Male", "Other / prefer not to say"}
        if sex not in allowed_sex:
            sex = "Not specified"
        try:
            age = int(age_raw) if age_raw else None
            if age is not None and not 0 <= age <= 120:
                raise ValueError
        except ValueError:
            flash("Please enter a valid age between 0 and 120.", "error")
            return redirect(url_for("patient"))
        if not selected and not suggestions:
            flash("Select at least one symptom or describe a symptom we can recognize.", "error")
            return redirect(url_for("patient"))
        # Never silently use free-text extraction: the user must confirm suggestions.
        session["pending_assessment"] = {
            "age": age, "sex": sex, "description": description,
            "selected": selected, "suggested": suggestions,
            "negated": extraction["negated"]
        }
        return redirect(url_for("review_symptoms"))

    return render_template("patient.html", active="patient", groups=symptom_groups())


@app.route("/review-symptoms", methods=["GET", "POST"])
def review_symptoms():
    pending = session.get("pending_assessment")
    if not pending:
        flash("There is no pending symptom review. Please start a new assessment.", "error")
        return redirect(url_for("patient"))
    if request.method == "POST":
        confirmed_suggestions = request.form.getlist("confirmed_suggestions")
        confirmed = list(dict.fromkeys(
            s for s in pending.get("selected", []) + confirmed_suggestions
            if s in SYMPTOM_KEYS
        ))
        session.pop("pending_assessment", None)
        if not confirmed:
            flash("Please confirm at least one symptom before continuing.", "error")
            return redirect(url_for("patient"))
        negated = list(dict.fromkeys(s for s in pending.get("negated", []) if s in SYMPTOM_KEYS and s not in confirmed))
        matches = calculate_matches(confirmed, negated)
        urgent = [URGENT_FLAGS[s] for s in confirmed if s in URGENT_FLAGS]
        top = matches[0] if matches else {"name": "No matching pattern", "score": 0}
        with db() as conn:
            cursor = conn.execute(
                "INSERT INTO screenings (created_at, age, sex, symptoms, top_match, top_score, negated_symptoms) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (utc_now(), pending.get("age"), pending.get("sex", "Not specified"), json.dumps(confirmed), top["name"], top["score"], json.dumps(negated)),
            )
            screening_id = cursor.lastrowid
        return redirect(url_for("prediction", screening_id=screening_id))

    selected = pending.get("selected", [])
    suggested = pending.get("suggested", [])
    return render_template(
        "review_symptoms.html", active="patient", selected=selected, suggested=suggested,
        negated=pending.get("negated", []), description=pending.get("description", ""),
        labels=SYMPTOM_LABELS, labels_bn=SYMPTOM_BN
    )


@app.route("/prediction/<int:screening_id>")
def prediction(screening_id: int):
    with db() as conn:
        record = conn.execute("SELECT * FROM screenings WHERE id=?", (screening_id,)).fetchone()
    if not record:
        flash("Screening record not found.", "error")
        return redirect(url_for("patient"))
    try:
        selected = json.loads(record["symptoms"])
        if not isinstance(selected, list):
            selected = []
    except (TypeError, json.JSONDecodeError):
        logger.exception("Invalid symptom JSON for screening %s", screening_id)
        selected = []
    selected = [s for s in selected if s in SYMPTOM_KEYS]
    try:
        negated = json.loads(record["negated_symptoms"]) if "negated_symptoms" in record.keys() else []
        if not isinstance(negated, list):
            negated = []
    except (TypeError, json.JSONDecodeError):
        negated = []
    negated = [s for s in negated if s in SYMPTOM_KEYS and s not in selected]
    matches = calculate_matches(selected, negated)
    urgent = [URGENT_FLAGS[s] for s in selected if s in URGENT_FLAGS]
    return render_template("prediction.html", active="prediction", record=record,
                           selected_labels=[SYMPTOM_LABELS[s] for s in selected],
                           negated_labels=[SYMPTOM_LABELS[s] for s in negated],
                           matches=matches, urgent=urgent)


@app.route("/analytics")
def analytics():
    with db() as conn:
        records = conn.execute("SELECT top_match, COUNT(*) AS count FROM screenings GROUP BY top_match ORDER BY count DESC").fetchall()
        total = conn.execute("SELECT COUNT(*) FROM screenings").fetchone()[0]
        latest = conn.execute("SELECT * FROM screenings ORDER BY id DESC LIMIT 10").fetchall()
    labels = [r["top_match"] for r in records]
    values = [r["count"] for r in records]
    return render_template("analytics.html", active="analytics", labels=json.dumps(labels), values=json.dumps(values), total=total, latest=latest, pattern_count=len(labels))


@app.route("/conditions")
def conditions_library():
    query = request.args.get("q", "").strip().lower()[:80]
    category = request.args.get("category", "All")
    rows = CONDITION_LIBRARY
    if category != "All":
        rows = [row for row in rows if row.get("category") == category]
    if query:
        rows = [row for row in rows if query in row.get("name_en", "").lower() or query in row.get("name_bn", "") or query in row.get("category", "").lower() or query in row.get("summary_en", "").lower() or query in row.get("summary_bn", "")]
    status = request.args.get("status", "All")
    if status == "Source checked":
        rows = [row for row in rows if row.get("content_review") == "source_content_checked_and_bilingual_summary_added"]
    elif status == "Pending review":
        rows = [row for row in rows if row.get("review_status") == "pending_condition_specific_review"]
    categories = sorted({row.get("category", "Other") for row in CONDITION_LIBRARY})
    return render_template("conditions.html", active="conditions", conditions=rows, categories=categories, query=query, selected_category=category, selected_status=status, total_conditions=len(CONDITION_LIBRARY), source_checked_count=sum(1 for x in CONDITION_LIBRARY if x.get("content_review") == "source_content_checked_and_bilingual_summary_added"), pending_count=sum(1 for x in CONDITION_LIBRARY if x.get("review_status") == "pending_condition_specific_review"))


@app.route("/conditions/<slug>")
def condition_detail(slug: str):
    condition = next((row for row in CONDITION_LIBRARY if row.get("id") == slug), None)
    if condition is None:
        abort(404)
    symptom_labels = [SYMPTOM_LABELS[s] for s in condition.get("symptom_ids", []) if s in SYMPTOM_LABELS]
    symptom_labels_bn = [SYMPTOM_BN.get(s, SYMPTOM_LABELS[s]) for s in condition.get("symptom_ids", []) if s in SYMPTOM_LABELS]
    source_checked = condition.get("content_review") == "source_content_checked_and_bilingual_summary_added"
    association = next((x for x in CONDITION_SYMPTOM_EVIDENCE.get("associations", []) if x.get("condition_id") == slug), None)
    return render_template("condition_detail.html", active="conditions", condition=condition, symptom_labels=symptom_labels, symptom_labels_bn=symptom_labels_bn, source_checked=source_checked, association=association)


@app.route("/symptom-map")
def symptom_map():
    """Browse source-listed symptom mentions; this page never feeds the matcher."""
    by_id = {row.get("id"): row for row in SYMPTOM_CATALOG.get("symptoms", [])}
    rows = []
    for association in CONDITION_SYMPTOM_EVIDENCE.get("associations", []):
        symptoms = [by_id[sid] for sid in association.get("symptom_ids", []) if sid in by_id]
        rows.append({**association, "symptoms": symptoms})
    query = request.args.get("q", "").strip().lower()[:80]
    if query:
        rows = [r for r in rows if query in r.get("condition_name_en", "").lower()
                or query in r.get("condition_name_bn", "")
                or any(query in s.get("label_en", "").lower() or query in s.get("label_bn", "")
                       or any(query in a.lower() for a in s.get("aliases", [])) for s in r["symptoms"])]
    return render_template("symptom_map.html", active="conditions", rows=rows, query=query,
                           association_total=len(CONDITION_SYMPTOM_EVIDENCE.get("associations", [])),
                           symptom_total=len(SYMPTOM_CATALOG.get("symptoms", [])),
                           mapping_issues=PHASE4_KNOWLEDGE_ISSUES)


@app.route("/feedback", methods=["GET", "POST"])
def feedback():
    if request.method == "POST":
        rating = request.form.get("rating", "")
        comment = request.form.get("comment", "").strip()[:1000]
        try:
            screening_id = int(request.form.get("screening_id") or 0) or None
        except ValueError:
            screening_id = None
        if screening_id is not None:
            with db() as conn:
                exists = conn.execute("SELECT 1 FROM screenings WHERE id=?", (screening_id,)).fetchone()
            if not exists:
                screening_id = None
        if rating not in {"Helpful", "Not helpful", "Needs review"}:
            flash("Please choose a valid feedback rating.", "error")
        else:
            with db() as conn:
                conn.execute("INSERT INTO feedback (created_at, screening_id, rating, comment) VALUES (?, ?, ?, ?)",
                             (utc_now(), screening_id, rating, comment))
            flash("Thank you. Your feedback was saved locally.", "success")
        return redirect(url_for("feedback"))
    with db() as conn:
        rows = conn.execute("SELECT * FROM feedback ORDER BY id DESC LIMIT 10").fetchall()
    return render_template("feedback.html", active="feedback", rows=rows)


@app.route("/settings", methods=["GET", "POST"])
def settings():
    if request.method == "POST":
        flash("No persistent application settings are configured in this educational prototype.", "success")
        return redirect(url_for("settings"))
    return render_template("settings.html", active="settings")


@app.errorhandler(400)
def bad_request(error):
    return render_template("404.html", active="", error_message=getattr(error, "description", "Invalid request.")), 400


@app.errorhandler(404)
def not_found(_error):
    return render_template("404.html", active="", error_message="The page you requested could not be found."), 404


if __name__ == "__main__":
    init_db()
    # Debug mode is opt-in for local development only. Never expose the dev server publicly.
    debug = os.environ.get("FLASK_DEBUG", "0") == "1"
    app.run(host=os.environ.get("FLASK_HOST", "127.0.0.1"), port=int(os.environ.get("PORT", "5000")), debug=debug)
else:
    init_db()
