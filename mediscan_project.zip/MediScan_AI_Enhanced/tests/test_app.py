import re
import json
import tempfile
import unittest
from pathlib import Path

import app as mediscan


class MediScanTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        mediscan.DB_PATH = Path(self.tmp.name) / "test.db"
        mediscan.app.config.update(TESTING=True, SECRET_KEY="test-secret")
        mediscan.init_db()
        self.client = mediscan.app.test_client()

    def tearDown(self):
        self.tmp.cleanup()

    def token(self):
        response = self.client.get("/patient")
        match = re.search(rb'name="csrf_token" value="([^"]+)"', response.data)
        self.assertIsNotNone(match)
        return match.group(1).decode()

    def test_security_headers_are_present(self):
        response = self.client.get("/")
        self.assertEqual(response.headers.get("X-Content-Type-Options"), "nosniff")
        self.assertEqual(response.headers.get("X-Frame-Options"), "DENY")
        self.assertEqual(response.headers.get("Referrer-Policy"), "strict-origin-when-cross-origin")
        self.assertIn("geolocation=()", response.headers.get("Permissions-Policy", ""))

    def test_prediction_report_is_not_cached(self):
        token = self.token()
        response = self.client.post("/patient", data={
            "csrf_token": token, "symptoms": ["fever"]
        }, follow_redirects=False)
        review = self.client.get(response.headers["Location"])
        match = re.search(rb'name="csrf_token" value="([^"]+)"', review.data)
        token2 = match.group(1).decode()
        response = self.client.post("/review-symptoms", data={
            "csrf_token": token2
        }, follow_redirects=False)
        report = self.client.get(response.headers["Location"])
        self.assertEqual(report.status_code, 200)
        self.assertEqual(report.headers.get("Cache-Control"), "no-store")

    def test_patient_page_has_accessible_search_and_selection_status(self):
        response = self.client.get("/patient")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'aria-live="polite"', response.data)
        self.assertIn(b'id="symptomNoResults"', response.data)
        self.assertIn(b"Review selected symptoms", response.data)

    def test_prediction_page_includes_print_action(self):
        token = self.token()
        self.client.post("/patient", data={"csrf_token": token, "symptoms": ["fever"]})
        review = self.client.get("/review-symptoms")
        match = re.search(rb'name="csrf_token" value="([^"]+)"', review.data)
        token2 = match.group(1).decode()
        response = self.client.post("/review-symptoms", data={
            "csrf_token": token2, "confirmed_suggestions": ["fever"]
        }, follow_redirects=False)
        report = self.client.get(response.headers["Location"])
        self.assertEqual(report.status_code, 200)
        self.assertIn(b'id="printReport"', report.data)

    def test_dashboard_loads(self):
        response = self.client.get("/")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"MediScan AI", response.data)

    def test_symptom_catalog_and_rules(self):
        self.assertGreaterEqual(len(mediscan.SYMPTOMS), 40)
        self.assertGreaterEqual(len(mediscan.CONDITIONS), 15)
        matches = mediscan.calculate_matches(["fever", "body_ache", "headache"])
        self.assertTrue(matches)
        self.assertIn("score", matches[0])
        self.assertGreaterEqual(matches[0]["score"], 0)
        self.assertLessEqual(matches[0]["score"], 100)

    def test_post_requires_csrf(self):
        response = self.client.post("/patient", data={"symptoms": "fever"})
        self.assertEqual(response.status_code, 400)

    def test_screening_flow_saves_and_shows_report(self):
        token = self.token()
        response = self.client.post("/patient", data={
            "csrf_token": token,
            "age": "22",
            "sex": "Not specified",
            "symptoms": ["fever", "body_ache", "headache"],
        }, follow_redirects=True)
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Symptom pattern report", response.data)
        self.assertIn(b"rule similarity", response.data.lower())

    def test_invalid_symptom_is_not_saved(self):
        token = self.token()
        response = self.client.post("/patient", data={
            "csrf_token": token,
            "symptoms": ["not_a_real_symptom"],
        }, follow_redirects=True)
        self.assertEqual(response.status_code, 200)
        with mediscan.db() as conn:
            count = conn.execute("SELECT COUNT(*) FROM screenings").fetchone()[0]
        self.assertEqual(count, 0)

    def test_feedback_is_saved(self):
        token = self.token()
        response = self.client.post("/feedback", data={
            "csrf_token": token,
            "rating": "Helpful",
            "comment": "Clear interface",
        }, follow_redirects=True)
        self.assertEqual(response.status_code, 200)
        with mediscan.db() as conn:
            count = conn.execute("SELECT COUNT(*) FROM feedback").fetchone()[0]
        self.assertEqual(count, 1)

    def test_missing_prediction_record_redirects(self):
        response = self.client.get("/prediction/9999", follow_redirects=False)
        self.assertEqual(response.status_code, 302)


    def test_bengali_symptom_extraction_suggests_fever_and_headache(self):
        result = mediscan.extract_symptoms_from_text("তিন দিন ধরে জ্বর ও মাথাব্যথা হচ্ছে")
        self.assertIn("fever", result["suggested"])
        self.assertIn("headache", result["suggested"])

    def test_english_negated_symptom_is_not_suggested(self):
        result = mediscan.extract_symptoms_from_text("I do not have fever but I have headache")
        self.assertNotIn("fever", result["suggested"])
        self.assertIn("fever", result["negated"])
        self.assertIn("headache", result["suggested"])

    def test_free_text_requires_confirmation_before_saving(self):
        token = self.token()
        response = self.client.post("/patient", data={
            "csrf_token": token,
            "symptom_description": "I have fever and headache",
        }, follow_redirects=False)
        self.assertEqual(response.status_code, 302)
        self.assertIn("review-symptoms", response.headers["Location"])
        with mediscan.db() as conn:
            self.assertEqual(conn.execute("SELECT COUNT(*) FROM screenings").fetchone()[0], 0)

    def test_confirmed_text_symptoms_are_saved(self):
        token = self.token()
        self.client.post("/patient", data={"csrf_token": token, "symptom_description": "I have fever"})
        review = self.client.get("/review-symptoms")
        match = re.search(rb'name="csrf_token" value="([^"]+)"', review.data)
        self.assertIsNotNone(match)
        token2 = match.group(1).decode()
        response = self.client.post("/review-symptoms", data={
            "csrf_token": token2, "confirmed_suggestions": ["fever"]
        }, follow_redirects=False)
        self.assertEqual(response.status_code, 302)
        with mediscan.db() as conn:
            row = conn.execute("SELECT symptoms FROM screenings ORDER BY id DESC LIMIT 1").fetchone()
        self.assertIn("fever", json.loads(row["symptoms"]))

    def test_health_library_lists_fifty_topics(self):
        self.assertEqual(len(mediscan.CONDITION_LIBRARY), 50)
        response = self.client.get("/conditions")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Explore health topics", response.data)

    def test_health_topic_detail_is_available_and_not_used_for_matching(self):
        response = self.client.get("/conditions/common-cold")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"NHS", response.data)
        row = next(x for x in mediscan.CONDITION_LIBRARY if x["id"] == "common-cold")
        self.assertFalse(row["usable_for_matching"])

    def test_unreviewed_topic_has_no_symptom_associations(self):
        row = next(x for x in mediscan.CONDITION_LIBRARY if x["id"] == "asthma")
        self.assertEqual(row["symptom_ids"], [])
        self.assertEqual(row["review_status"], "pending_condition_specific_review")


    def test_phase3_source_review_counts_and_status_filter(self):
        checked = [x for x in mediscan.CONDITION_LIBRARY if x.get("content_review") == "source_content_checked_and_bilingual_summary_added"]
        self.assertGreaterEqual(len(checked), 10)
        self.assertTrue(all(x.get("usable_for_matching") is False for x in mediscan.CONDITION_LIBRARY))
        response = self.client.get("/conditions?status=Source+checked")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Dengue", response.data)

    def test_knowledge_catalogue_validation_rejects_matchable_library_record(self):
        sample = {"id":"x", "name_en":"X", "name_bn":"এক্স", "category":"Other", "source_name":"Source", "source_url":"https://www.nhs.uk/x", "review_status":"reviewed", "symptom_ids":[], "usable_for_matching":True}
        issues = mediscan.validate_condition_library([sample])
        self.assertTrue(any("must not be enabled for matching" in issue for issue in issues))

    def test_dengue_and_malaria_have_source_links_but_are_not_matchable(self):
        for cid in ("dengue", "malaria"):
            row = next(x for x in mediscan.CONDITION_LIBRARY if x["id"] == cid)
            self.assertTrue(row["source_url"].startswith("https://"))
            self.assertFalse(row["usable_for_matching"])
            self.assertTrue(row["symptom_ids"])


    def test_phase4_symptom_catalog_has_unique_ids_and_bilingual_labels(self):
        rows = mediscan.SYMPTOM_CATALOG["symptoms"]
        ids = [row["id"] for row in rows]
        self.assertEqual(len(ids), len(set(ids)))
        self.assertTrue(all(row.get("label_en") and row.get("label_bn") for row in rows))

    def test_phase4_source_symptom_map_is_not_matchable(self):
        self.assertGreaterEqual(len(mediscan.CONDITION_SYMPTOM_EVIDENCE["associations"]), 9)
        self.assertTrue(all(row["usable_for_matching"] is False for row in mediscan.CONDITION_SYMPTOM_EVIDENCE["associations"]))
        response = self.client.get("/symptom-map")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Condition-symptom reference map", response.data)

    def test_bengali_negated_fever_is_not_suggested(self):
        result = mediscan.extract_symptoms_from_text("আমার জ্বর নেই কিন্তু মাথাব্যথা হচ্ছে")
        self.assertNotIn("fever", result["suggested"])
        self.assertIn("fever", result["negated"])
        self.assertIn("headache", result["suggested"])


    def test_matching_explains_matched_and_not_assessed_symptoms(self):
        matches = mediscan.calculate_matches(["fever", "headache"])
        self.assertTrue(matches)
        top = matches[0]
        self.assertIn("matched", top)
        self.assertIn("not_assessed", top)
        self.assertIn("not a disease probability", top["interpretation"].lower())

    def test_negated_symptoms_are_separate_from_positive_matches(self):
        matches = mediscan.calculate_matches(["headache"], ["fever"])
        self.assertTrue(matches)
        for item in matches:
            self.assertNotIn("Fever", item["matched"])
        influenza = next(x for x in matches if x["name"] == "Influenza-like pattern")
        self.assertIn("Fever", influenza["explicitly_not_present"])

    def test_existing_database_gets_negated_symptom_column(self):
        with mediscan.db() as conn:
            columns = {row["name"] for row in conn.execute("PRAGMA table_info(screenings)")}
        self.assertIn("negated_symptoms", columns)

    def test_unknown_text_is_not_converted_to_negative_symptom(self):
        result = mediscan.extract_symptoms_from_text("আজ শরীরটা অদ্ভুত লাগছে")
        self.assertEqual(result["suggested"], [])
        self.assertEqual(result["negated"], [])


if __name__ == "__main__":
    unittest.main()
