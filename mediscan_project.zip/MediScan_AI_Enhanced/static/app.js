document.addEventListener("DOMContentLoaded", () => {
  // Persistent light/dark appearance preference.
  const root = document.documentElement;
  const toggle = document.getElementById("themeToggle");
  const applyTheme = theme => {
    root.dataset.theme = theme;
    if (toggle) {
      const icon = toggle.querySelector(".theme-icon");
      const label = toggle.querySelector(".theme-label");
      if (icon) icon.textContent = theme === "dark" ? "☾" : "☀";
      if (label) label.textContent = theme === "dark" ? "Dark mode" : "Light mode";
      toggle.setAttribute("aria-label", `Switch to ${theme === "dark" ? "light" : "dark"} mode`);
    }
    try { localStorage.setItem("mediscan-theme", theme); } catch (_) { /* storage may be unavailable */ }
  };
  let savedTheme = "dark";
  try { savedTheme = localStorage.getItem("mediscan-theme") || "dark"; } catch (_) { /* use default */ }
  applyTheme(savedTheme === "light" ? "light" : "dark");
  if (toggle) toggle.addEventListener("click", () => applyTheme(root.dataset.theme === "dark" ? "light" : "dark"));

  // Accessible mobile navigation controls.
  const menuToggle = document.getElementById("mobileMenuToggle");
  const sidebar = document.getElementById("sidebarNav");
  const closeMenu = () => {
    document.body.classList.remove("nav-open");
    if (menuToggle) {
      menuToggle.setAttribute("aria-expanded", "false");
      menuToggle.setAttribute("aria-label", "Open navigation");
    }
  };
  if (menuToggle) {
    menuToggle.addEventListener("click", () => {
      const isOpen = document.body.classList.toggle("nav-open");
      menuToggle.setAttribute("aria-expanded", String(isOpen));
      menuToggle.setAttribute("aria-label", isOpen ? "Close navigation" : "Open navigation");
    });
  }
  if (sidebar) sidebar.querySelectorAll("a").forEach(link => link.addEventListener("click", closeMenu));
  document.addEventListener("keydown", event => {
    if (event.key === "Escape") closeMenu();
  });

  const printButton = document.getElementById("printReport");
  if (printButton) printButton.addEventListener("click", () => window.print());

  const symptomBoxes = [...document.querySelectorAll("[data-symptom]")];
  const count = document.getElementById("selectedCount");
  const updateCount = () => { if (count) count.textContent = symptomBoxes.filter(x => x.checked).length; };
  symptomBoxes.forEach(box => box.addEventListener("change", updateCount));
  updateCount();

  const clear = document.getElementById("clearSymptoms");
  if (clear) clear.addEventListener("click", () => setTimeout(updateCount, 0));

  const search = document.getElementById("symptomSearch");
  if (search) {
    search.addEventListener("input", () => {
      const query = search.value.trim().toLowerCase();
      document.querySelectorAll("[data-symptom-group]").forEach(group => {
        let visible = 0;
        group.querySelectorAll("[data-symptom]").forEach(item => {
          const label = item.querySelector(".symptom-label");
          const haystack = `${item.dataset.label} ${label?.dataset.bn || ""}`.toLowerCase();
          const match = !query || haystack.includes(query);
          item.hidden = !match;
          if (match) visible += 1;
        });
        group.hidden = visible === 0;
      });
      const noResults = document.getElementById("symptomNoResults");
      if (noResults) noResults.hidden = document.querySelectorAll("[data-symptom]:not([hidden])").length > 0;
    });
  }


  // English/Bengali symptom-label switch (assessment page only).
  const langButtons = [...document.querySelectorAll("[data-lang-choice]")];
  const symptomLabels = [...document.querySelectorAll(".symptom-label[data-en][data-bn]")];
  const searchInput = document.getElementById("symptomSearch");
  const setLanguage = lang => {
    symptomLabels.forEach(el => { el.textContent = lang === "bn" ? el.dataset.bn : el.dataset.en; });
    langButtons.forEach(btn => btn.classList.toggle("active", btn.dataset.langChoice === lang));
    if (searchInput) searchInput.placeholder = lang === "bn" ? "বাংলা বা ইংরেজিতে লক্ষণ খুঁজুন..." : "Search symptoms in English or Bengali...";
    try { localStorage.setItem("mediscan-language", lang); } catch (_) { /* optional preference */ }
  };
  if (langButtons.length) {
    let lang = "en";
    try { lang = localStorage.getItem("mediscan-language") || "en"; } catch (_) { /* default */ }
    setLanguage(lang === "bn" ? "bn" : "en");
    langButtons.forEach(btn => btn.addEventListener("click", () => setLanguage(btn.dataset.langChoice)));
  }

  const patternCanvas = document.getElementById("patternChart");
  if (patternCanvas && window.Chart) {
    new Chart(patternCanvas, {
      type: "bar",
      data: { labels: window.patternLabels || [], datasets: [{ label: "Saved screenings", data: window.patternValues || [], backgroundColor: "rgba(36,199,221,.78)", borderColor: "#35d9e8", borderWidth: 1, borderRadius: 7, maxBarThickness: 38 }] },
      options: {
        responsive: true,
        plugins: { legend: { display: false }, tooltip: { callbacks: { label: context => `${context.parsed.x ?? context.parsed.y} saved screening(s)` } } },
        scales: {
          x: { beginAtZero: true, ticks: { color: "#93a7bd", precision: 0 }, grid: { color: "rgba(150,180,210,.08)" } },
          y: { ticks: { color: "#c4d0df" }, grid: { display: false } }
        }
      }
    });
  }
});
