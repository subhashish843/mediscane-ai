# MediScan AI — Enhanced Educational Symptom-Pattern Screening Prototype

MediScan AI is a Flask + SQLite educational web application. It compares user-selected symptoms with **17 illustrative, hand-authored weighted symptom-pattern profiles** and displays up to five ranked similarity matches.

> **Important:** This is not a trained AI/ML model, medical device, diagnosis tool, probability estimator, or clinical risk calculator. The rules and weights are illustrative and have not been clinically validated. A displayed similarity score is only a mathematical overlap score against a hand-authored profile. Use fictional data only. Do not use this application to make medical decisions or delay professional/emergency care.

## Phase 3: source-tracked bilingual knowledge review

- Expanded source-checked educational summaries from 4 to 11 topics using official NHS, MedlinePlus, CDC and WHO pages.
- Added source check date, source type, content review state, clinical-review requirement, and explicit matching block reason.
- Added status filtering and search across English/Bengali names and summaries.
- Added catalogue integrity validation and tests that prevent health-library records from being enabled for matching.
- The remaining 39 topics are still pending condition-specific source review.
- Source checking is not clinician review or clinical validation. No health-library record is used for matching.

## Phase 2: bilingual health-topic library

- Added a searchable library of 50 bilingual health-topic catalogue records.
- Added source-linked summaries for four topics (common cold, flu, UTI, sinusitis), based on the cited NHS/MedlinePlus pages.
- Remaining 46 topics are explicitly marked as awaiting condition-specific source review.
- The library is informational only and is not connected to the matching engine.
- Added `/conditions` and `/conditions/<slug>` pages.

## What's improved

- Refined responsive dark navy/cyan interface.
- Expanded symptom catalog with category grouping and live search.
- Expanded illustrative pattern library from 7 to 17 profiles.
- Added English/Bengali symptom labels and bilingual keyword phrase recognition.
- Added a symptom review/confirmation step: free-text suggestions are never used without user confirmation.
- Added basic negation phrase handling and tests for English/Bengali examples.
- Clearer explanation of matched symptoms and similarity-score meaning.
- Emergency warning prompts for selected red-flag symptoms.
- Input allow-list validation and de-duplication.
- CSRF token validation for POST forms.
- Secret key moved to environment configuration (random per-process fallback for local demo).
- Debug mode disabled by default; local-only host binding by default.
- SQLite indexes and safer database connection settings.
- Corrected analytics chart to show saved-record counts by top match.
- Automated tests for the main routes and screening workflow.
- `.gitignore` and `.env.example` added.

## Technology stack

- Python 3.10+
- Flask 3.x
- Jinja2 templates
- HTML, CSS, JavaScript
- SQLite
- Chart.js (loaded from CDN for charts)

## Run on Windows (VS Code terminal / CMD)

```cmd
py -m venv venv
venv\Scripts\activate
python -m pip install -r requirements.txt
python app.py
```

Open <http://127.0.0.1:5000>.

If the `venv` folder already exists, do not create it again. Activate it and install requirements.

## Run on macOS / Linux

```bash
python3 -m venv venv
source venv/bin/activate
python -m pip install -r requirements.txt
python app.py
```

## Configuration

Copy `.env.example` to `.env` and set a strong `MEDISCAN_SECRET_KEY`. Flask does not automatically load `.env`; set environment variables in your shell or use a trusted environment loader if you add one.

Windows CMD example for the current terminal session:

```cmd
set MEDISCAN_SECRET_KEY=replace-with-a-long-random-secret
set FLASK_DEBUG=0
python app.py
```

Optional variables:

- `MEDISCAN_SECRET_KEY`: Flask session signing key.
- `MEDISCAN_DB_PATH`: SQLite database path. Defaults to `mediscan.db` beside `app.py`.
- `FLASK_HOST`: Defaults to `127.0.0.1` (local machine only).
- `PORT`: Defaults to `5000`.
- `FLASK_DEBUG`: Defaults to `0`; only enable for local development.
- `LOG_LEVEL`: Defaults to `INFO`.

Do not expose Flask's built-in development server to the public internet. A real deployment requires a production WSGI server, HTTPS, authentication/authorization, secure secret management, privacy controls, backups, monitoring, and a security review.

## Run tests

```bash
python -m unittest discover -s tests -v
python knowledge/validate_catalogue.py
```

## Project structure

```text
mediscan_ai_project/
├── app.py
├── requirements.txt
├── README.md
├── .env.example
├── .gitignore
├── mediscan.db              # generated automatically at runtime; not included in source ZIP
├── tests/
│   └── test_app.py
├── knowledge/
│   └── conditions.json
├── templates/
│   ├── base.html
│   ├── dashboard.html
│   ├── patient.html
│   ├── conditions.html
│   └── condition_detail.html
│   ├── prediction.html
│   ├── analytics.html
│   ├── feedback.html
│   ├── settings.html
│   └── 404.html
└── static/
    ├── style.css
    └── app.js
```

## Current limitations

- Pattern profiles and weights are manually authored and illustrative.
- Age and sex are stored with the demo record but are not used by the matching algorithm.
- The system does not contain a trained ML model or external AI API.
- Bilingual free-text recognition is a conservative phrase dictionary, not NLP/LLM or clinical language understanding; it may miss or misread context.
- Bengali/English phrase coverage is limited to the explicit alias dictionary.
- The condition profiles remain illustrative and are not source-reviewed clinical associations.
- Similarity scores are not calibrated probabilities or disease likelihoods.
- The symptom list and pattern library are limited and cannot cover the full range of medical conditions.
- No user authentication or multi-user access control is implemented.
- SQLite is intended for a local educational prototype, not a high-volume multi-user clinical system.
- No clinical validation, regulatory review, or medical professional approval is claimed.

## Safety

If someone has severe or rapidly worsening symptoms, seek professional medical help. For emergency warning signs such as severe breathing difficulty, chest pain, fainting, new confusion, sudden one-sided weakness, or sudden severe allergic swelling, contact local emergency services immediately. Do not wait for this application.


## Phase 4 additions
See `PHASE4_KNOWLEDGE_INTEGRATION.md`. The new Symptom Evidence Map is informational only and is not connected to the weighted prediction matcher.


## Phase 5 updates
The result report distinguishes matched symptoms, symptoms reported as not present, and symptoms that were not assessed. Unselected symptoms are not treated as negative. The displayed score is an illustrative overlap with a manually authored rule profile, not a probability or diagnosis.

Run tests after installing dependencies:

```bash
python -m unittest discover -s tests -v
```

See `PHASE5_EXPLAINABLE_MATCHING_AND_SAFETY.md` for details and limitations.


## Phase 6 — verification and basic security hardening

- Added browser security headers: `X-Content-Type-Options`, `X-Frame-Options`,
  `Referrer-Policy`, and a restrictive `Permissions-Policy`.
- Prediction/report responses use `Cache-Control: no-store` to reduce browser caching
  of locally stored screening details.
- Added regression tests for the security headers and report cache policy.
- Existing CSRF checks, parameterized SQL queries, input limits, and non-debug
  default remain in place.
- This is a code-level hardening pass, not a penetration test or clinical validation.


## Phase 7 — UI polish and accessibility
- Added keyboard skip navigation, visible focus states, accessible mobile menu controls, and an empty search-results message.
- Added assistive-technology announcements for the selected symptom count.
- Added browser-native print support for screening reports.
- Existing English/Bengali symptom labels and light/dark themes are preserved.
