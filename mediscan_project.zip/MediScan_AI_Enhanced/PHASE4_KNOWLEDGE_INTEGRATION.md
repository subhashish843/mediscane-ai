# Phase 4 — Canonical Symptom & Source Evidence Integration

## Delivered
- `knowledge/symptoms.json`: canonical bilingual symptom vocabulary generated from the existing application catalogue, with English/Bengali labels, aliases, category, and a clear non-diagnostic definition.
- `knowledge/condition_symptom_evidence.json`: source-listed symptom mentions for source-checked topics, with source URL, date, provenance, and explicit `usable_for_matching: false` / `clinician_reviewed: false` flags.
- `/symptom-map`: searchable read-only view of source-listed condition–symptom mentions.
- Health-topic detail pages now show association provenance and explicitly state that symptom mentions are not used by the prediction matcher.
- Conservative bilingual negation handling improved for common English prefixes and Bengali suffixes such as `জ্বর নেই` and `জ্বর হচ্ছে না`.
- Added tests for canonical vocabulary integrity, map safety, Bengali negation, and unknown text.

## Critical separation
The 17 existing illustrative weighted rules remain the only active matching rules. The 50-topic educational library and Phase 4 source evidence map are not used by `calculate_matches()`. Source-listed symptom mentions are not clinical validation, diagnostic criteria, or calibrated probabilities. No new condition is promoted into matching.

## Unknown / missing data semantics
- A symptom not mentioned by the patient remains unknown; it is not treated as absent.
- Unrecognized free text remains unparsed and is not converted into a negative finding.
- Extracted phrases remain suggestions until patient confirmation.
- A negative phrase is kept separate from positive suggestions and is not silently converted into a model input.

## Verification
- Python syntax compilation and JSON integrity checks are performed during packaging.
- Flask runtime tests require installing `requirements.txt` locally; this environment did not have Flask installed, so they are supplied but not claimed as executed.
