# Phase 5 — Explainable Matching and Safety

## Implemented
- Matching results now expose matched symptoms, symptoms not assessed, and explicitly negated symptoms separately.
- Unselected symptoms are never described as absent.
- Explicitly negated symptoms are stored in a separate SQLite `negated_symptoms` column and are excluded from positive matching.
- Existing SQLite databases are upgraded with a safe additive column migration.
- Result page explains that the score is only overlap with a manually authored illustrative profile, not disease probability, diagnostic confidence, or clinical risk.
- Emergency warning flags continue to be triggered only by positively confirmed selected symptoms.
- Review screen clarifies that phrase-based negation detection can make mistakes.

## Important limitations
- The current matcher remains a manually authored rule-profile similarity system, not a validated diagnostic model.
- The score is not calibrated and should not be used for triage or treatment.
- The simple bilingual phrase matcher is not a full natural-language understanding system. Users must confirm suggestions.
- Absence of a selected symptom means `not assessed`, not `absent`.
- Emergency guidance is a conservative warning only and does not replace emergency services or professional assessment.

## Database migration
On startup, `init_db()` checks the existing `screenings` table and adds `negated_symptoms TEXT NOT NULL DEFAULT '[]'` if missing. Existing records remain intact.

## Verification
- Python compilation: passed.
- Full Flask unit tests: not executed successfully in this build environment because Flask is not installed (`ModuleNotFoundError: flask`). Run locally after installing `requirements.txt`:
  `python -m unittest discover -s tests -v`
